---
name: make-podcast-ad
description: End-to-end standalone workflow for podcast-style AI video ads — a vertical podcast clip of one to four speakers where Seedance 2.0 generates both the footage and the voices, with GPT Image 2 base images locking each speaker's look from a real podcast-set photo. Self-contained; needs no other files or repo — covers research, personas, angles, script writing, character and voice design, base-image generation, clip generation, the full ffmpeg edit (cuts, punch-in zooms, product overlay, burned-in captions, music bed, finishing grade), delivery to Notion and Google Drive, and syncing the brand folder to shared storage. kie.ai (generation) and Cloudflare R2 (storage) are swappable defaults — on first run the skill interviews the user for their vendor choices and API keys and saves them to .env. Use whenever someone wants a podcast-style or talking-head video ad, an AI-generated podcast clip, a UGC "two people talking" ad, or says "make a podcast ad" in any form.
---

# Make a podcast ad — standalone, end to end

Make a podcast-style video ad: one to four people in conversation, one on screen at a time,
simple straight cuts. **Seedance 2.0 generates the footage and the voices**; **GPT Image 2**
locks each speaker's look in a base image first; **ffmpeg** cuts the final ad; shared storage
keeps the brand's working tree; **Notion** and **Google Drive** deliver to the client. kie.ai
(generation) and Cloudflare R2 (storage) are the documented defaults, and both are swappable —
see "Swapping vendors". Everything needed is in this file — API calls included. The ad can be
**any length** and in **any language**: clips are capped by the video model (15 seconds on
Seedance), so longer just means more clips back to back.

## Setup — the first-run interview

The first time this skill runs, set the person up **in chat** before any ad work:

1. **Check the machine:** `curl`, `jq`, `ffmpeg` + `ffprobe` (a build with libass — check
   `ffmpeg -filters | grep ass`). Optional: `whisperx` for word-accurate captions
   (`uv tool install --python 3.12 whisperx`), `rclone` or the `aws` CLI for bucket sync.
2. **Ask which vendors they're using.** The defaults work out of the box; every slot is
   swappable (see "Swapping vendors"):
   - **Generation** (images, video, music) — kie.ai, one key for all three. Or another
     provider/host.
   - **Shared storage** — Cloudflare R2. Or any S3-compatible bucket, a shared Drive folder, or
     none at all — local-only is fine for solo work.
   - **Client delivery** — a Notion board and/or Google Drive, per how their client reviews.
3. **Ask for the API keys those choices need** and save each one straight to `.env` in the
   working directory as it arrives. Never repeat a key back in chat and never log one; offer the
   alternative of the person adding it to `.env` themselves.
4. **Confirm the brand folder** exists (layout below), then start at step 1.

Skip the interview when `.env` already holds what the session needs; after that, ask only for
what's missing, at the moment a step needs it.

`.env` with the defaults:

```
KIE_API_KEY=            # generation (kie.ai default — image, video, music in one key)
HF_TOKEN=               # optional — Hugging Face, caption transcription fallback
R2_ACCOUNT_ID=          # storage (R2 default; any S3-compatible bucket works)
R2_ACCESS_KEY_ID=
R2_SECRET_ACCESS_KEY=
R2_BUCKET=
NOTION_TOKEN=           # or a connected Notion integration/MCP
                        # Google Drive: a connected Drive integration/MCP, or browser upload
```

### Swapping vendors

The craft in this file — prompts, gates, edit rules — is vendor-independent; only the API blocks
are kie.ai/R2-specific, and those are reference implementations, not requirements. A replacement
just has to cover the same capability:

- **Image model** (step 6): image-to-image editing from a reference photo at 9:16 — GPT Image 2
  or an equivalent editing model, on any host.
- **Video model** (step 9): must take character reference images as keyframes **and** generate
  the spoken dialogue natively from the prompt — Seedance 2.0 or an equivalent, on any host
  (the vendor's own API, fal.ai, Replicate…). Set step 8's per-clip split to that model's max
  clip length; 15 seconds is Seedance's cap, not a law of the format.
- **Music** (step 10e): any licensed source or generator; Suno via kie.ai is just the default.
- **Storage** (step 12): anything the team shares, keeping the brand-folder layout as the unit.

On a non-default vendor, follow its API docs for the calls and keep every prompt, rule, and gate
in this file unchanged.

**Brand folder** — one folder per brand, this exact shape (it mirrors the team's R2 layout, so
work round-trips):

```
<Brand>/
  inputs/
    <product>-research.md      # source of truth (structure in step 1)
    <product>-personas.md
    <product>-angles.md
    feedback.md                # standing client guidance ledger
    reviews.csv                # pulled or supplied reviews
    media/                     # product images, brand kit (logo, fonts)
  outputs/
    json/<id>.json             # one record per ad (step 12)
    <ad-name>/                 # per-ad working folder: base/, clips, edit files, edit-final.mp4
  references/                  # the podcast-set photo bank (step 4) + index.md
```

If shared storage is set up, **pull the brand before working and push when done** (step 12) —
the mirror is last-write-wins with no merge history.

## How to work

- Run the steps in order. **At each step, show the artifact and wait for the user** — early
  choices (persona, voices, set) propagate everywhere.
- **Never just one answer:** propose **3 deliberately differentiated options** for every creative
  element, as a plain numbered list in chat. Anything the brief already defines is decided — skip
  its options.
- **The user picks every winner** — rolls, takes, scripts. Never grade creative output yourself.
- Show images inline as markdown embeds; compare alternatives in one table row, one image per
  cell. Video gets a clickable file link, never a raw path to copy.
- Verify renders silently with `ffprobe` (duration, streams, audio present) — no frame pulls or
  QA images unless the user asks.

## The kie.ai job pattern (used by steps 6 and 9)

On the default vendor, all image and video generation is the same three calls. (A different
vendor follows its own docs — usually the same shape: upload refs → create job → poll.)

**1. Upload local files** (reference images) — http(s) URLs skip this:

```bash
curl -s -X POST https://kieai.redpandaai.co/api/file-stream-upload \
  -H "Authorization: Bearer $KIE_API_KEY" \
  -F "file=@<local file>" -F "uploadPath=images/podcast-ads"
```

The hosted URL is `.data.downloadUrl` in the response. `uploadPath` is just a storage folder name.

**2. Create the task:**

```bash
curl -s -X POST https://api.kie.ai/api/v1/jobs/createTask \
  -H "Authorization: Bearer $KIE_API_KEY" -H "Content-Type: application/json" \
  -d '<payload — see the step>'
```

The task id is `.data.taskId`.

**3. Poll until done** — every 5s; give up after 300s for images, 600s for video:

```bash
curl -s "https://api.kie.ai/api/v1/jobs/recordInfo?taskId=<taskId>" \
  -H "Authorization: Bearer $KIE_API_KEY"
```

`.data.state` is `success`, `fail`, or pending. On fail, the reason is `.data.failMsg`. On
success the output URL is **inside a JSON string that must be parsed again**:
`.data.resultJson | fromjson | .resultUrls[0]`. Download it with a plain `curl -o`; trust the
response `content-type` for the extension (kie sometimes returns jpg when png was asked).

Transient errors (HTTP 5xx, "temporarily unavailable"): retry the whole create+poll up to 3
times. HTTP 402 means the account is out of credits — stop and tell the user.

## 1. Research

Ground every ad in the brand's research files. If they exist, read them — don't re-summarize
(paraphrase drift is how claims get overstated). If the brand is new or thin, build them:

**Reviews first.** If no `reviews.csv` was supplied, pull the store's public review feed —
these are the same feeds the on-page widgets read, no API key:

- **Okendo** — page HTML contains `subscriberId":"<uuid>"`. Feed:
  `https://api.okendo.io/v1/stores/<uuid>/reviews?limit=100`, follow `nextUrl`.
- **Judge.me** — keyed by the store's `.myshopify.com` domain (in page HTML):
  `https://api.judge.me/reviews/reviews_for_widget?shop_domain=<dom>&platform=shopify&product_id=<id>&page=N&per_page=30`.
  Reviews are shared across grouped sister products — crawl every id in the store's
  `/products.json` and dedupe by `uuid`.
- **Stamped, Loox, Yotpo, Reviews.io** — feed keyed by ids in the page HTML; read the rendered
  widget if no JSON feed. If a platform resists, ask the user to supply the CSV instead.

Columns: `review_number, date, product, rating, reviewer, verified, incentivized, title, body`.
**Never fabricate reviews, quotes, or counts.** Sanity-check the count and average against the
public product page, and flag incentivized reviews.

**`<product>-research.md`** — write it from the product page, web search, and the reviews. Quote
customers verbatim; write `Unknown` rather than guess. Sections:

- **Overview** — what it is, link, who it's for, how it works + unique mechanism, why people buy.
- **Details** — every concrete spec: ingredients/materials with amounts, dimensions, build.
- **Selling points** — feature → functional benefit → emotional benefit.
- **Market** — background, position, sophistication stage 1–5 (1 first-to-market · 2 direct
  claims · 3 mechanism · 4 better mechanism · 5 identity/experience).
- **Competitors** — competitor · price · their differentiation · ours.
- **Branding** — colors in hex labeled by use, fonts, case + punctuation conventions, tone.
- **Reviews analysis** — count, rating, distribution; then insight + verbatim quote per: physical
  pains, emotional pains, desired outcomes, reasons to buy, objections (+ counter).

**`<product>-personas.md`** — a table, ≥5 rows to start, grounded in reviews, never invention:
`name (2–4 words) | age (specific) | gender | awareness stage (unaware · problem-aware ·
solution-aware · product-aware · most-aware, + note) | physical pain | emotional pain | desired
outcome | objection`.

**`<product>-angles.md`** — a table, ≥5 rows: `angle (2–4 word name) | the claim + why it lands
for the persona`. An angle is any way to sell — feature, benefit, market fact, offer, season, a
standout review, a competitor gap. **One ad communicates one angle.**

**`feedback.md`** — standing client guidance, one imperative rule per line with why + source +
date. Read it before every ad; when the client gives durable guidance, add it here (one-off fixes
don't belong).

**The gate:** the user signs off which product, which persona + angle (picked in step 2), and the
**2–4 claims** this ad will carry. If a claim isn't in the research doc, it doesn't go in the
script.

## 2. Concept

Settle element by element, 3 differentiated options each:

- **Product** — usually set by step 1's gate.
- **Persona** — from the persona table; propose fresh ones when none fits (append the pick).
- **Angle** — from the angle table, likewise.
- **Target market** — sets the **accent** of the voices (US → American, UK → British…) and the
  idioms of the script. Any language works — write the script in it, design voices to match.
- **Speaker count** — a one-, two-, three-, or four-person show.

## 3. Characters

Design each speaker — look **and** sound. Per speaker: age, ethnicity, look, outfit; then a
**detailed voice design**: register (alto/mezzo, low/high), timbre (warm, breathy, smooth,
raspy), pace, intonation, energy, accent, quirks (a soft laugh, a touch of vocal fry). Propose 3
differentiated casts; the user locks one.

Make the voices **clearly contrasting** — a low, warm alto against a bright, airy mezzo. Seedance
generates voices straight from this text; similar descriptions blur into the same voice. The
voice block gets pasted **verbatim into every clip prompt**, so write it once and write it well.

## 4. Reference

Pick a **real podcast-set photo** from `references/` (keep an `index.md`: id · file · vibe ·
framing · notes). No bank yet, or nothing fits? Ask the user for one — a frame from a show they
like, a web search (`<vibe> podcast setup`), a real set shot — and add it to the bank so it
grows. Show candidates side by side in one table row and let the user choose.

**The reference sets how real the final video looks.** If the photo looks AI-generated, the
output will too — the bank holds real photographs only.

Give every speaker their own **facing** so intercut singles read as one conversation: the second
speaker uses a horizontally flipped copy of the reference
(`ffmpeg -i ref.png -vf hflip ref-flipped.png`) — the mic sits on the opposite side, one speaker
angled screen-left, the other screen-right. Three or four speakers: keep assigning facings and
mic sides that hold that geometry. A one-person show skips this.

## 5. Base-image prompts

One base image per character: an image-to-image edit of the reference — first speaker on the
chosen photo, second on its flipped copy. The prompt is a **pure edit-instruction list**: only
the changes you want, nothing else.

- **Don't describe the reference** — the model sees it; describing invites redrawing. No
  meta-words: never "photorealistic", "fictional", any realism/retouch language, and never
  "soft" — it triggers retouched skin.
- **Replace the person with the designed character**, writing imperfections in as affirmative
  detail: visible pores, slightly uneven skin tone with faint redness, subtle under-eye shadows,
  sun freckles, peach fuzz, flyaways and baby hairs. This keeps skin organic instead of
  AI-polished.
- **Wardrobe, pose, framing, expression** per the character design — angled to match the
  reference's facing.
- **Strip branding** — remove show text/logos from mic and set; no text anywhere in the image.
- **End with the lock:** "add fine sensor noise like a paused frame of real interview footage;
  keep the photo's texture, natural skin texture, grain, contrast, and pixel-level detail exactly
  the same — only replace the person and apply the edits listed. Keep everything else exactly the
  same."

## 6. Generate the base images

Per character, upload their reference (kie.ai job pattern step 1), then run the same prompt
**three times** — GPT varies run to run — with this payload:

```json
{ "model": "gpt-image-2-image-to-image",
  "input": { "prompt": "<the edit-instruction prompt>",
             "aspect_ratio": "9:16", "resolution": "1K",
             "input_urls": ["<uploaded reference URL>"] } }
```

Three separate tasks (they can run in parallel); save as `outputs/<ad-name>/base/<character>-a.png`,
`-b`, `-c`. The second speaker's `input_urls` is the flipped reference. Keep each prompt in a
`.txt` beside the images. Show the rolls in one table row per character; **the user picks**. If
no roll lands, tighten the prompt and reroll.

Base images deliberately come **before** the script: the script gets written to real faces, not
descriptions.

## 7. Script

Write a very casual, speech-like conversation between the characters, built from the signed-off
claims and the research doc's customer language. Offer 3 differentiated scripts; agree the target
length. Label every line `MAYA (HOST):` / `CHLOE (GUEST):`.

**Writing law** (applies to all ad copy):

- **Outcome-led, not descriptive** — lead with the result the persona gets, not the feature.
- **Concrete, never vague or aspirational** — every line names something the reader can picture
  ("sleep through the night"), never a mood ("feel confident again").
- **Honest and substantiated** — say what the reviews support, don't exaggerate.
- **One angle per ad.** Active voice. Customer language from the reviews.
- **No em dashes** in any on-screen or spoken copy.
- **Cold audience:** the first mention of the product is brand + plain category ("the Acme Focus
  protein bar"), never a bare sub-brand the listener can't place. The opening line is the hook —
  it must make what-this-is / who-it's-for / why-care land fast.

**Dialogue craft** (podcast-specific):

- **One sentence = one shot.** Keep lines short.
- **Speech-like flow, never punchy:** contractions, fillers, a false start, the odd trailing
  off — dialogue earns the fillers banned on static creatives. Read it aloud; if it sounds
  written, loosen it.
- **Interruptions:** end a line with a trailing "-" so the other speaker barges in.
- **Hedge vs. certainty:** a layperson is unsure about mechanisms ("don't quote me on the
  science, but…") and certain about her own experience. The mix reads as real.
- **Echoes:** the host repeats a fragment back ("two weeks?") — the one clipped fragment that
  belongs; it keeps it a conversation, not alternating monologues.
- **Product out of frame:** the product graphic goes on screen in the edit, not the footage —
  write the dialogue so nothing needs showing.
- **On-screen text vs. spoken word:** captions follow the brand's text conventions; the spoken
  line uses the natural word. Write each for its medium.

## 8. Video prompts

Split the script into consecutive clips of **15 seconds or less** (Seedance's cap — use the
chosen video model's cap if it differs); round durations up to whole seconds. **Time for the render, not the page:** Seedance pads delivery, so pack more words per
second than spoken-pace math suggests; if a rendered clip drags, shorten its duration to compress
delivery (five lines that sag at 13s land at 11s).

Write each clip prompt **fully self-contained** — restate every character, the set, and which
reference image is which; never reference another clip. Structure with labeled blocks:

- **TASK** — bring lines X–Y to life, vertical 9:16. Use each character's base image exactly as
  their keyframe: do not redraw, restyle, recrop, relight, or change set, wardrobe, faces, or
  composition. Camera fully locked — no pans, zooms, push-ins, tilts, shake. Only the person on
  screen moves, in micro-movements: natural blink rate, collarbone breathing, head moves of a
  centimeter or two, small low hand moves. Move between lines with simple hard straight cuts,
  one person on screen at a time; each cut lands exactly on the incoming speaker's first word,
  that speaker already in subtle motion at the cut (mid-breath, mid-nod), never from stillness.
- **AUDIO** — no music. Only voices plus natural sound (soft breaths, a chair creak, fabric near
  the mic); room tone continuous and unbroken across every cut. Brisk pacing, no dead air — each
  line begins on the tail of the previous one. Hold each voice exactly consistent.
- **VOICES** — the step-3 voice block, **pasted verbatim and identical in every clip**, saying
  which character is which. Identical wording is what keeps voices from drifting between clips.
- **SHOTS** — per line: who is on screen, exact expression and gesture (hands and face do the
  acting), the exact spoken line. Expressions move **with** the words and relax as the line
  ends — never hold or grow a smile after a line finishes; end every shot mid-energy. Cue
  interruptions with the barging-in voice starting a beat before the cut.
- **REACTIONS** — between cuts, the off-screen person reacts quietly (a soft "mhm", a small
  laugh, a breath) fitting or anticipating the line. This sells the realism — write it rich,
  never skip it.

Keep prompts tight and value-dense. The realism carriers are the micro-details in SHOTS and
REACTIONS — spend your words there.

## 9. Generate the clips

Once the user approves the prompts: upload each speaking character's base image (job pattern
step 1, `uploadPath=videos/podcast-ads`), then one task per clip:

```json
{ "model": "bytedance/seedance-2-mini",
  "input": { "prompt": "<the full clip prompt>",
             "aspect_ratio": "9:16", "resolution": "720p",
             "duration": 12, "generate_audio": true,
             "reference_image_urls": ["<host base URL>", "<guest base URL>"] } }
```

- `duration` — integer 4–15. Max 9 image refs; pass the base image of each character who appears.
- **Default to `bytedance/seedance-2-mini`** — its takes have beaten full `bytedance/seedance-2`
  at half the price, and 720p is a shippable master. 1080p means a fresh roll on the full model
  (a re-render is a new take, not an upscale) — that call is the user's.
- Keep `generate_audio: true`; the no-music rule lives in the prompt text.
- Clips can generate in parallel. Poll with a 600s deadline. Save to
  `outputs/<ad-name>/clip-01.mp4`, `clip-02.mp4`, …
- Verify each silently with `ffprobe`. If a take misses (wrong voice, drifting face, dragged
  pacing), reroll that clip — same prompt, or tightened.

## 10. Edit

The clips are clean by design — no music, no on-screen product. The edit adds pacing, the
product overlay, captions, music, and finish. Generation costs money; the edit is free — iterate
in seconds, re-render over the same `edit-final.mp4`, keep no versioned copies.

**Build an edit plan first and show it in chat** — a timeline table (clip · trim · punch-ins ·
seconds), caption text **verbatim**, overlay + music + finish choices. The user signs off before
you render. Every revision note maps to a plan tweak plus a re-render.

### 10a. Transcribe (timing truth)

Timing truth is the rendered audio, not the script — generated speakers deliver on their own
clock. Simplest flow: assemble the cut **without captions** first, transcribe that single file,
re-render with captions.

- **whisperx** (preferred):
  `whisperx cut.mp4 --model large-v3 --output_format json --output_dir /tmp/wx --device cpu --compute_type int8`
  → JSON with word-level `start`/`end`.
- **HF fallback** (needs `HF_TOKEN`): extract audio
  (`ffmpeg -y -i cut.mp4 -vn -ac 1 -ar 16000 -c:a flac audio.flac`), then POST it base64-encoded:
  `{"inputs": "<base64>", "parameters": {"return_timestamps": "word"}}` to
  `https://router.huggingface.co/hf-inference/models/openai/whisper-large-v3` with
  `Authorization: Bearer $HF_TOKEN` and `x-wait-for-model: true`. Words come back as
  `chunks: [{text, timestamp: [start, end]}]`.
- **Neither**: line-level timing — find speech bounds with ffmpeg `silencedetect`, spread the
  script lines across them, and tell the user timings are approximate.

The word timestamps also mark the exact **cut points** for trimming dead air.

### 10b. Assemble the cut

Normalize every trimmed clip to identical specs, then concat. Per clip:

```
[i:v] trim=start=S:end=E, setpts=PTS-STARTPTS, fps=30,
      scale=1080:1920:force_original_aspect_ratio=decrease,
      pad=1080:1920:(ow-iw)/2:(oh-ih)/2, setsar=1, format=yuv420p [vi]
[i:a] atrim=start=S:end=E, asetpts=PTS-STARTPTS, aresample=48000,
      aformat=sample_fmts=fltp:channel_layouts=stereo [ai]
```

then `[v0][a0][v1][a1]…concat=n=N:v=1:a=1[vt][at]`. Render staged (intermediates then a final
pass) or as one `-filter_complex` — staged is easier to debug; re-renders are free either way.

**Craft:**

- **Pacing** — cut on the dialogue's beats; trim dead air at clip heads and tails using the word
  timestamps. **Hard cuts are the default** for podcast ads. Where a beat needs softening, a
  crossfade earns its place at 0.12–0.2s (`xfade=transition=fade:duration=0.15:offset=<junction-0.15>`
  + `acrossfade=d=0.15`) — longer reads as slow. Note every crossfade shortens the timeline by
  its duration; shift downstream caption/overlay times accordingly.
- **Speed** — a beat can slow to 50–70%: `setpts=PTS/0.6` + `atempo=0.6` (atempo only accepts
  0.5–2.0 per instance; chain two for more). Much slower looks like a glitch.
- **Punch-ins** — on emphasis beats (the key claim, a reaction, the payoff), aligned to the claim
  word via the transcript. Scale to a 2x master, then zoompan with a ramped zoom:

  ```
  [vt] scale=2160:3840, zoompan=z='1+(TO-1)*clip((in/30-ST)/0.12,0,1)*clip((EN-in/30)/0.12,0,1)'
       :x='iw*0.5-(iw/zoom/2)':y='ih*0.35-(ih/zoom/2)':d=1:s=1080x1920:fps=30 [vz]
  ```

  `TO` 1.06–1.10 (stronger reads as a glitch), `ST`/`EN` the event's start/end seconds, 0.12s
  ramps, anchor y ≈ 0.35 for faces. A handful per 30s at most — every beat punched is no beat
  punched.
- **Stills as motion** — a still (product shot) used as b-roll gets Ken Burns instead of sitting
  frozen: `-loop 1 -i still.png`, then `fps=30, trim=end=DUR, setpts=PTS-STARTPTS,
  scale=2160:3840 (2x), zoompan` with a slow drift `z='1.0+(0.05)*(in/30)/DUR'` — 1.03–1.08 total,
  barely-there.

### 10c. Product overlay

The product graphic (from `inputs/media/`, background removed if needed) composites over the
footage at the beat where the product is named:

```
[1:v] format=rgba, scale=380:-2,
      fade=t=in:st=START:d=0.2:alpha=1, fade=t=out:st=END-0.2:d=0.2:alpha=1 [ov]
[vz][ov] overlay=x='main_w*0.80-w/2':y='main_h*0.16-h/2':enable='between(t,START,END)' [vo]
```

A graphic entering the frame reads better sliding in than appearing — add an eased offset to the
position: `x='main_w*0.80-w/2 + (main_w - (main_w*0.80-w/2))*pow(1-clip((t-START)/0.3,0,1),3)'`
(from the right; analogous for other edges; ~0.3s).

**Placement law:** clear negative space only — never over a face, never over the caption band.
Legible at thumbnail size but supporting, not dominating. Match the brand's colors and fonts
(from research.md's Branding section); highlight key words with weight or an accent color, keep
consistent margins, give everything room.

### 10d. Captions

Karaoke pace is the default for ads: **2–4 words per event**, split on the word timestamps, each
event ending where the next starts; max 2 lines; stay in the lower title-safe band. On-screen
text follows the brand's spelling/casing conventions even when the spoken word differs — fix
transcript errors before they burn in; keep the transcript's timings.

Burn with libass. Generate `captions.ass`:

```
[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Helvetica Neue,96,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,3,0,2,65,65,672,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 0,0:00:00.20,0:00:01.10,Cap,,0,0,0,,SO I TRIED
Dialogue: 0,0:00:01.10,0:00:02.05,Cap,,0,0,0,,THE ACME BAR
```

- Colors are `&H00BBGGRR` (hex reversed): white fill `&H00FFFFFF`, black stroke `&H00000000`.
- Defaults that work at 1080x1920: size ≈ 96 (5% of height), outline 3, alignment 2
  (lower-center), MarginV ≈ 672 (35% of height keeps it clear of platform UI), MarginL/R ≈ 65.
- Times are `H:MM:SS.CC` (centiseconds).
- **Fonts:** Helvetica Neue Bold (the system `.ttc`) is the clean default. Heavier "CapCut look":
  a Google font like Archivo Black or Montserrat ExtraBold — fetch the static TTF by requesting
  `https://fonts.googleapis.com/css2?family=Archivo+Black:wght@400` with header
  `User-Agent: Mozilla/5.0 (Windows NT 5.1)` (the legacy UA makes Google return a plain `.ttf`
  URL in the CSS), download it into a `fonts/` dir. A brand font only when a licensed file exists
  in the brand kit — never hunt the web for a commercial font.
- Apply **last** in the video chain: `ass=captions.ass:fontsdir=fonts`.

### 10e. Music

Podcast ads often ship without music — never block on it. When wanted:

**Source clean:** user-supplied, copyright-free, or generated. Never rip a commercial or trending
track — an unlicensed song in a client ad is a copyright claim waiting. Generate via kie.ai
(Suno) — note the different endpoints:

```bash
curl -s -X POST https://api.kie.ai/api/v1/generate \
  -H "Authorization: Bearer $KIE_API_KEY" -H "Content-Type: application/json" \
  -d '{ "model": "V4_5", "customMode": true, "instrumental": true,
        "style": "<the music prompt>", "title": "<track name>",
        "callBackUrl": "https://example.com/suno-callback" }'
```

`callBackUrl` is a required-but-unused placeholder — poll instead:
`GET https://api.kie.ai/api/v1/generate/record-info?taskId=<id>` until `.data.status` is
`SUCCESS`; tracks are `.data.response.sunoData[].audioUrl` — **each roll returns two full-length
takes**. `SENSITIVE_WORD_ERROR` means an artist/brand name tripped the filter — reword, don't
retry. Style prompt ≤1000 chars.

**Prompt like a producer:** micro-genre + BPM + production markers ("jersey club, 140bpm,
sidechained 808s, pitched-up chops"), ending "hook-first, loopable, no intro" — the slow
stock-music intro is the boring tell. Instrumental under dialogue; never sung lyrics. Never name
artists or songs. Roll 3 differentiated directions; the user picks. Choose the vibe against the
brand voice in research.md.

**Levels — a bed, not a lead:**

```
[2:a] aresample=48000, aformat=sample_fmts=fltp:channel_layouts=stereo,
      volume=-18dB, afade=t=in:st=0:d=0.5, afade=t=out:st=DUR-1:d=1,
      atrim=start=0:end=DUR, asetpts=PTS-STARTPTS [mus]
[at] asplit=2 [amain][akey]
[mus][akey] sidechaincompress=threshold=0.02:ratio=10:attack=20:release=250:makeup=1 [mduck]
[amain][mduck] amix=inputs=2:duration=first:dropout_transition=3:normalize=0,
               loudnorm=I=-14:TP=-1.5:LRA=11, aresample=48000,
               aformat=sample_fmts=fltp:channel_layouts=stereo [aout]
```

-18dB gain under dialogue (a few dB louder only where no one speaks); the sidechain ducks the
bed under every line automatically; the fade-out is timed so the trim doesn't sound like a cut;
loudnorm masters to -14 LUFS. Without music, skip loudnorm — `[at]` passes straight to `[aout]`.

### 10f. Finish + encode

A light pass takes the AI edge off — it should read as footage, not a filter:

```
eq=contrast=1.05:saturation=1.05, curves=all='0/0.03 0.25/0.27 0.75/0.73 1/1', noise=alls=6:allf=t+u
```

`noise alls` = grain: 4–8 is the working band (0.2–0.4 intensity). Order: punch-ins → overlays →
finish → captions last. Encode:

```
-map "[vout]" -map "[aout]" -c:v libx264 -crf 18 -preset medium -c:a aac -b:a 192k -movflags +faststart
```

Render in the foreground with a generous timeout — never as a detached background job. `ffprobe`
the result silently (duration vs plan, streams). The user judges the render; loop plan-tweak →
re-render until approved.

## 11. Deliver

**Naming** — every deliverable: `[ID]_9x16_[Product]_[Persona]_[Angle]_Podcast[_Offer]`, e.g.
`7_9x16_Acme_BusyParent_Reframe_Podcast`. ID = next integer; if the brand reviews on a Notion Ads
Board, the board is the ID authority (max existing ID + 1), else scan `outputs/`.

**Notion (client review):** the brand's Ads Board database. One page per ad, named by the
convention. Properties (match the board's actual schema): Status (e.g. `Pending Client Review`),
Product, Media = `Video`, Ratio = `9:16`, Headline + Primary Text (the Meta copy — headline ≈
40 chars; primary text one sentence per line, blank line between). Page body: the filename as a
heading + the media. Clips under Notion's ~20MB cap embed directly; anything over goes to Drive
and the page's link property carries the Drive folder URL. Upserts match by page name — safe to
re-run.

**Editor handoff** (when an editor does the finish instead of 10b–10f): push the raw clips to
Notion/Drive plus an **editing instructions** block: the opening hook (name the exact script
line), subtitles yes/no + style, exact clip order, zoom-in/out moments, background-music
direction (trending, copyright-free), and a finishing note to add a little noise and experiment
with highlights/shadows — it reduces the AI look.

**Drive (files):** folder structure `<workspace Drive folder>/<Brand>/<ad name>/`. Find the
existing brand folder (match by name, case-insensitive) — **never create folders without the
user confirming**; upload with correct video mime types. Video masters live in Drive, not Notion.

## 12. Record + sync

Write one record per ad at `outputs/json/<id>.json` — it makes the work portable and auditable:

```json
{ "id": 7,
  "status": "planned | generated | approved | synced",
  "concept": { "product": "", "persona": "", "angle": "", "format": "Podcast" },
  "copy": { "script": "<the full labeled script>" },
  "design": "cast + set notes",
  "generation": {
    "model": "bytedance/seedance-2-mini", "resolution": "720p", "aspect": "9:16",
    "clips": [ { "prompt": "<clip 1 prompt>", "duration": 12, "output": "clip-01.mp4" } ],
    "refs": ["base/host-a.png", "base/guest-b.png"], "generatedAt": "<iso>" },
  "edit": "timeline + overlay + captions + music summary",
  "output": "7_9x16_Acme_BusyParent_Reframe_Podcast.mp4" }
```

**Shared storage** (optional — solo work can stay local): the brand folder mirrors wherever the
team shares files. The default is Cloudflare R2 (S3-compatible; endpoint
`https://$R2_ACCOUNT_ID.r2.cloudflarestorage.com`, brand as key prefix); any S3-compatible
bucket works the same with its own endpoint, and a shared Drive folder does the job too. With
the aws CLI:

```bash
aws s3 sync <Brand>/ "s3://$R2_BUCKET/<Brand>/" \
  --endpoint-url "https://$R2_ACCOUNT_ID.r2.cloudflarestorage.com" --exclude ".*" --exclude "*/.*"
```

(or `rclone sync` with an S3 remote). **Pull before you start, push when you finish** — reverse
source/target to pull. The mirror is last-write-wins with no merge: if teammates work the same
brand, coordinate before pushing over their changes. Text, records, and the final mp4 all go up;
dotfiles never do.
